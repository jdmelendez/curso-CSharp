﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BucleFor
{
    class Program
    {
        static void Main(string[] args)
        {
            string nombre = "Cursos Ángel Arias";
            Console.WriteLine(nombre.Length);
            Console.ReadKey();

        }
    }
}
